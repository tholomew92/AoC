﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace aoc_14_1
{
    class Program
    {
        List<string> input = File.ReadAllLines(@"C:\Users\Sebbe\Desktop\aoc\2020\14\input.txt").ToList();

        void ParseBits()
        {
            Dictionary<string, string> memory = new Dictionary<string, string>();
            string mask = "";
            foreach(var row in input)
            {
                if (row.StartsWith("mask"))
                {
                    mask = row[7..];
                }
                else 
                {
                    int stopPos = row.IndexOf(']');
                    string mempos = row[5..stopPos];
                    int value = int.Parse(row[(stopPos + 4)..]);
                    string bitValue = Convert.ToString(value, 2);
                    bitValue = bitValue.PadLeft(36, '0');
                    string newValue = "";
                    for (int i = 0; i < mask.Length; i++)
                    {
                        if (!mask[i].Equals('X'))
                        {
                            newValue += mask[i].ToString();
                        }
                        else
                        {
                            newValue += bitValue[i].ToString();
                        }
                    }
                    if (!memory.ContainsKey(mempos)) memory.Add(mempos, newValue);
                    else memory[mempos] = newValue;
                }
            }
            long total = 0;
            foreach(var value in memory)
            {
                total += Convert.ToInt64(value.Value,2);
            }
            Console.WriteLine(total);
        }

        static void Main(string[] args)
        {
            Program p = new Program();
            p.ParseBits();
        }
    }
}
